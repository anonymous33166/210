import os
from typing import Dict, Any

AZURE_OPENAI_CONFIG = {
    "api_key": "Cy6PhC0o8zbzKJZkGNP4T6PVZawguyDl6vQp22GRx38s0vOke6UbJQQJ99BHACYeBjFXJ3w3AAABACOGUCQY",
    "endpoint": "https://iscas.openai.azure.com/",
    "deployment_name": "gpt-4o",
    "api_version": "2024-12-01-preview",
    "max_tokens": 2000,
    "temperature": 0.7
}

def get_azure_openai_config() -> Dict[str, Any]:
    """Get default Azure OpenAI configuration."""
    return AZURE_OPENAI_CONFIG.copy()

def get_azure_openai_config_from_env() -> Dict[str, Any]:
    """Load Azure OpenAI configuration from environment variables (lab aliases supported)."""
    config = {
        "api_key": os.getenv("AZURE_OPENAI_API_KEY", AZURE_OPENAI_CONFIG["api_key"]),
        "endpoint": os.getenv("AZURE_OPENAI_ENDPOINT",
                            os.getenv("ENDPOINT_URL", AZURE_OPENAI_CONFIG["endpoint"]))
            or AZURE_OPENAI_CONFIG["endpoint"],
        "deployment_name": os.getenv("AZURE_OPENAI_DEPLOYMENT",
                                   os.getenv("DEPLOYMENT_NAME", AZURE_OPENAI_CONFIG["deployment_name"]))
            or AZURE_OPENAI_CONFIG["deployment_name"],
        "api_version": os.getenv("AZURE_OPENAI_API_VERSION", AZURE_OPENAI_CONFIG["api_version"]),
        "max_tokens": int(os.getenv("AZURE_OPENAI_MAX_TOKENS", AZURE_OPENAI_CONFIG["max_tokens"])),
        "temperature": float(os.getenv("AZURE_OPENAI_TEMPERATURE", AZURE_OPENAI_CONFIG["temperature"]))
    }
    return config

def validate_azure_openai_config(config: Dict[str, Any]) -> bool:
    """Validate Azure OpenAI configuration."""
    required_fields = ["api_key", "endpoint", "deployment_name", "api_version"]

    for field in required_fields:
        if not config.get(field):
            print(f"[error] Missing required config field: {field}")
            return False

    if len(config["api_key"]) < 50:
        print("[warn] API key format may be invalid")

    if not str(config["endpoint"]).startswith("https://"):
        print(f"[warn] Endpoint should start with https://: {config['endpoint']}")

    if not str(config["endpoint"]).endswith("/"):
        print(f"[warn] Endpoint should end with '/': {config['endpoint']}")

    if "gpt-4" not in str(config["deployment_name"]).lower():
        print(f"[warn] Deployment may not be a GPT-4 family model: {config['deployment_name']}")

    return True

def get_lab_environment_variables() -> Dict[str, str]:
    """Return lab environment variable presets (for local testing)."""
    return {
        "AZURE_OPENAI_API_KEY": "Cy6PhC0o8zbzKJZkGNP4T6PVZawguyDl6vQp22GRx38s0vOke6UbJQQJ99BHACYeBjFXJ3w3AAABACOGUCQY",
        "AZURE_OPENAI_ENDPOINT": "https://iscas.openai.azure.com/",
        "AZURE_OPENAI_DEPLOYMENT": "gpt-4o",
        "AZURE_OPENAI_API_VERSION": "2024-12-01-preview",
        # Lab aliases
        "ENDPOINT_URL": "https://iscas.openai.azure.com/",
        "DEPLOYMENT_NAME": "gpt-4o"
    }

def setup_lab_environment():
    """Set lab Azure OpenAI environment variables if not already present."""
    lab_vars = get_lab_environment_variables()

    print("[setup] Initializing lab Azure OpenAI environment variables...")

    for var_name, var_value in lab_vars.items():
        if not os.getenv(var_name):
            os.environ[var_name] = var_value
            print(f"[set] {var_name}")
        else:
            print(f"[skip] {var_name} already present")

if __name__ == "__main__":
    print("[test] Azure OpenAI GPT-4o configuration")

    setup_lab_environment()

    default_config = get_azure_openai_config()
    print("[ok] Default config loaded")
    print(f"  API Key: {default_config['api_key'][:20]}...")
    print(f"  Endpoint: {default_config['endpoint']}")
    print(f"  Deployment: {default_config['deployment_name']}")
    print(f"  API Version: {default_config['api_version']}")

    env_config = get_azure_openai_config_from_env()
    print("\n[ok] Env config loaded")
    print(f"  API Key: {env_config['api_key'][:20]}...")
    print(f"  Endpoint: {env_config['endpoint']}")
    print(f"  Deployment: {env_config['deployment_name']}")
    print(f"  API Version: {env_config['api_version']}")


    if validate_azure_openai_config(env_config):
        print("\n[ok] Configuration validated")
    else:
        print("\n[error] Configuration invalid")