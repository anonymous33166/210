import json
import os
import csv
from typing import Dict, List, Any, Optional, Union
from pathlib import Path

class DatasetLoader:
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        self.supported_formats = ['.json', '.csv', '.txt']
        
        self.dataset_cache = {}
    
    def load_dataset(self, dataset_name: str, format_type: str = "auto") -> Dict[str, Any]:
        
        cache_key = f"{dataset_name}_{format_type}"
        if cache_key in self.dataset_cache:
            return self.dataset_cache[cache_key]
        
        dataset_file = self._find_dataset_file(dataset_name, format_type)
        if not dataset_file:
            raise FileNotFoundError(f"Dataset not found: {dataset_name}")
        
        if dataset_file.suffix == '.json':
            data = self._load_json(dataset_file)
        elif dataset_file.suffix == '.csv':
            data = self._load_csv(dataset_file)
        elif dataset_file.suffix == '.txt':
            data = self._load_txt(dataset_file)
        else:
            raise ValueError(f"Unsupported file format: {dataset_file.suffix}")
        
        self.dataset_cache[cache_key] = data
        
        print(f"[✅] Dataset {dataset_name} loaded: {len(data)} records")
        return data
    
    def _find_dataset_file(self, dataset_name: str, format_type: str = "auto") -> Optional[Path]:
        if format_type == "auto":
            for fmt in self.supported_formats:
                file_path = self.data_dir / f"{dataset_name}{fmt}"
                if file_path.exists():
                    return file_path
        else:
            if not format_type.startswith('.'):
                format_type = f".{format_type}"
            file_path = self.data_dir / f"{dataset_name}{format_type}"
            if file_path.exists():
                return file_path
        
        return None
    
    def _load_json(self, file_path: Path) -> Dict[str, Any]:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if isinstance(data, list):
                return {
                    "type": "list",
                    "data": data,
                    "count": len(data),
                    "metadata": {
                        "source": str(file_path),
                        "format": "json"
                    }
                }
            elif isinstance(data, dict):
                if "metadata" not in data:
                    data["metadata"] = {}
                data["metadata"]["source"] = str(file_path)
                data["metadata"]["format"] = "json"
                return data
            else:
                raise ValueError(f"Invalid JSON data format: {type(data)}")
                
        except Exception as e:
            raise RuntimeError(f"Failed to load JSON file {file_path}: {e}")
    
    def _load_csv(self, file_path: Path) -> Dict[str, Any]:
        try:
            data = []
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    data.append(row)
            
            return {
                "type": "list",
                "data": data,
                "count": len(data),
                "metadata": {
                    "source": str(file_path),
                    "format": "csv",
                    "columns": list(data[0].keys()) if data else []
                }
            }
            
        except Exception as e:
            raise RuntimeError(f"Failed to load CSV file {file_path}: {e}")
    
    def _load_txt(self, file_path: Path) -> Dict[str, Any]:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            data = []
            for line in lines:
                line = line.strip()
                if line and not line.startswith('#'):
                    data.append(line)
            
            return {
                "type": "list",
                "data": data,
                "count": len(data),
                "metadata": {
                    "source": str(file_path),
                    "format": "txt"
                }
            }
            
        except Exception as e:
            raise RuntimeError(f"Failed to load TXT file {file_path}: {e}")
    
    def get_dataset_info(self, dataset_name: str) -> Dict[str, Any]:
        try:
            data = self.load_dataset(dataset_name)
            return {
                "name": dataset_name,
                "count": data.get("count", 0),
                "type": data.get("type", "unknown"),
                "metadata": data.get("metadata", {}),
                "sample": data.get("data", [])[:3] if data.get("data") else []
            }
        except Exception as e:
            return {
                "name": dataset_name,
                "error": str(e)
            }
    
    def list_available_datasets(self) -> List[Dict[str, Any]]:
        datasets = []
        
        for file_path in self.data_dir.glob("*"):
            if file_path.is_file() and file_path.suffix in self.supported_formats:
                dataset_name = file_path.stem
                try:
                    info = self.get_dataset_info(dataset_name)
                    datasets.append(info)
                except Exception as e:
                    datasets.append({
                        "name": dataset_name,
                        "error": str(e)
                    })
        
        return datasets
    
    def create_sample_dataset(self, dataset_name: str, dataset_type: str = "24point"):
        if dataset_type == "24point":
            sample_data = [
                {
                    "id": "24p_001",
                    "numbers": [3, 8, 3, 8],
                    "problem": "Use numbers 3, 8, 3, 8 to reach 24 via + - * /",
                    "solution": "(8*3) + (8*3) = 48, incorrect. Try again: 8*3 = 24",
                    "difficulty": "medium"
                },
                {
                    "id": "24p_002", 
                    "numbers": [4, 5, 6, 7],
                    "problem": "Use numbers 4, 5, 6, 7 to reach 24 via + - * /",
                    "solution": "(7-4)*(6-5) = 3*1 = 3, incorrect. Try: 7*4 - (6+5) = 17",
                    "difficulty": "hard"
                },
                {
                    "id": "24p_003",
                    "numbers": [1, 2, 3, 4],
                    "problem": "Use numbers 1, 2, 3, 4 to reach 24 via + - * /",
                    "solution": "4*3*2*1 = 24",
                    "difficulty": "easy"
                }
            ]
        elif dataset_type == "legal":
            sample_data = [
                {
                    "id": "legal_001",
                    "case_type": "contract_dispute",
                    "problem": "Analyze a contract dispute: Party A signs a sales contract with Party B, A delays payment, B seeks rescission and damages.",
                    "solution": "Under Contract Law, delayed payment constitutes breach...",
                    "difficulty": "medium"
                },
                {
                    "id": "legal_002",
                    "case_type": "intellectual_property",
                    "problem": "Explain legal bases for IP protection",
                    "solution": "Statutes include Copyright Law, Patent Law, Trademark Law, etc...",
                    "difficulty": "hard"
                }
            ]
        else:
            sample_data = [
                {
                    "id": f"{dataset_type}_001",
                    "problem": f"This is a sample {dataset_type} problem",
                    "solution": "This is a sample answer",
                    "difficulty": "medium"
                }
            ]
        
        dataset_file = self.data_dir / f"{dataset_name}.json"
        with open(dataset_file, 'w', encoding='utf-8') as f:
            json.dump({
                "type": "list",
                "data": sample_data,
                "count": len(sample_data),
                "metadata": {
                    "source": str(dataset_file),
                    "format": "json",
                    "created_by": "DatasetLoader",
                    "dataset_type": dataset_type
                }
            }, f, ensure_ascii=False, indent=2)
        
        print(f"[✅] Sample dataset {dataset_name} created: {dataset_file}")
        return dataset_file
    
    def clear_cache(self):
        self.dataset_cache.clear()
        print(f"[🧹] Dataset cache cleared")

    def load_24point(self) -> List[Dict[str, Any]]:
        try:
            data = self.load_dataset("24point_dataset", "json")
            return data.get("data", [])
        except FileNotFoundError:
            print("[⚠️] 24-point dataset not found, creating base dataset")
            self.create_sample_dataset("24point_dataset", "24point")
            data = self.load_dataset("24point_dataset", "json")
            return data.get("data", [])
    
    def load_24point_extended(self) -> List[Dict[str, Any]]:
        try:
            data = self.load_dataset("comprehensive_24point_67_dataset", "json")
            return data.get("data", [])
        except FileNotFoundError:
            print("[⚠️] 67-problem 24-point dataset not found, trying extended dataset")
            try:
                data = self.load_dataset("extended_24point_dataset", "json")
                return data.get("data", [])
            except FileNotFoundError:
                print("[⚠️] Extended 24-point dataset not found, using base dataset")
                return self.load_24point()
    
    def load_24point_comprehensive_67(self) -> List[Dict[str, Any]]:
        data = self.load_dataset("comprehensive_24point_67_dataset", "json")
        return data.get("data", [])
    
    
    def load_mathematics(self) -> List[Dict[str, Any]]:
        """Load mathematics dataset"""
        try:
            data = self.load_dataset("mathematics_dataset", "json")
            return data.get("data", [])
        except FileNotFoundError:
            print("[⚠️] Mathematics dataset not found")
            return []
    
    def load_coding(self) -> List[Dict[str, Any]]:
        try:
            data = self.load_dataset("coding_dataset", "json")
            return data.get("data", [])
        except FileNotFoundError:
            print("[⚠️] Coding dataset not found")
            return []
    
    def load_legal(self) -> List[Dict[str, Any]]:
        try:
            data = self.load_dataset("legal_dataset", "json")
            return data.get("data", [])
        except FileNotFoundError:
            print("[⚠️] Legal dataset not found")
            return [] 

    def load_gaokao_math(self) -> List[Dict[str, Any]]:
        try:
            data = self.load_dataset("gaokao_math_dataset", "json")
            return data.get("data", [])
        except FileNotFoundError:
            print("[⚠️] Gaokao math dataset not found")
            return []

    def load_leetcode(self) -> List[Dict[str, Any]]:
        try:
            data = self.load_dataset("leetcode_dataset", "json")
            return data.get("data", [])
        except FileNotFoundError:
            print("[⚠️] LeetCode dataset not found")
            return [] 

    def load_zhongkao_math(self) -> List[Dict[str, Any]]:
        try:
            data = self.load_dataset("zhongkao_math_dataset", "json")
            return data.get("data", [])
        except FileNotFoundError:
            print("[⚠️] Zhongkao math dataset not found")
            return []

    def validate_gaokao_answers(self) -> Dict[str, Any]:
        info = {"total": 0, "missing": 0, "bad_format": 0, "details": []}
        try:
            data = self.load_dataset("gaokao_math_dataset", "json")
            items = data.get("data", [])
            info["total"] = len(items)
            for it in items:
                qid = it.get("id")
                ans_type = str(it.get("answer_type",""))
                exp = it.get("expected_answer")
                if exp is None or str(exp).strip() == "":
                    info["missing"] += 1
                    info["details"].append({"id": qid, "issue": "missing_expected"})
                    continue
                if ans_type.lower() == "multiple_choice":
                    if str(exp).strip().upper() not in {"A","B","C","D"}:
                        info["bad_format"] += 1
                        info["details"].append({"id": qid, "issue": "choice_not_in_ABCD", "expected": exp})
        except Exception as e:
            info["error"] = str(e)
        return info 